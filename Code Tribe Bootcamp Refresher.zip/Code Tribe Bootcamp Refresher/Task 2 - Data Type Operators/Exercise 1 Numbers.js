// 1. Declare a number variable and assign it a value
let number1 = 10;

// 2. Declare a number variable and assign it a floating number
let number2 = 3.14;

// 3. Perform arithmetic operations with number variables
let resultAddition = number1 + number2;
let resultSubtraction = number1 - number2;
let resultMultiplication = number1 * number2;
let resultDivision = number1 / number2;
let resultModulus = number1 % number2;
let resultExponentiation = number1 ** number2;

// 4. Print all your variables
console.log("number1:", number1);
console.log("number2:", number2);
console.log("resultAddition:", resultAddition);
console.log("resultSubtraction:", resultSubtraction);
console.log("resultMultiplication:", resultMultiplication);
console.log("resultDivision:", resultDivision);
console.log("resultModulus:", resultModulus);
console.log("resultExponentiation:", resultExponentiation);