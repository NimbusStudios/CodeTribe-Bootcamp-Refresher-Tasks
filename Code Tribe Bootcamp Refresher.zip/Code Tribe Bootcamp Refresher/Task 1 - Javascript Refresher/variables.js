

let name = "Nkululeko Sedibe";
let age = "34";
let isStudent = true;

console.log("Name:", name);
console.log("Is Student:", isStudent);
console.log("Age:", age);


