// Print numbers from 1 to 10:
for (let i = 1; i <= 10; i++) {
    console.log(i);
}

// Print all even numbers between 1 and 20:
for (let i = 2; i <= 20; i += 2) {
    console.log(i);
}

// Calculate the sum of all numbers from 1 to 100 and print the result:
let sum = 0;

for (let i = 1; i <= 100; i++) {
    sum += i;
}

console.log(sum);

// Print all multiples of 5 less than 50:
for (let i = 0; i < 50; i += 5) {
    console.log(i + 1);
}